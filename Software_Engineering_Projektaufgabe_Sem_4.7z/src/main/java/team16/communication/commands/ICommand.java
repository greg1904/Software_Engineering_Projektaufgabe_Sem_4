package team16.communication.commands;

public interface ICommand { //SOLID-Prinzip: Command
    void execute();
}
