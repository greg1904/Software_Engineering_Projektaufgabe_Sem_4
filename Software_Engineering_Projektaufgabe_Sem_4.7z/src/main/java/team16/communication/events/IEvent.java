package team16.communication.events;

public interface IEvent {
}
