package team16.communication.events;

public class StartSortingEvent implements IEvent {
}
