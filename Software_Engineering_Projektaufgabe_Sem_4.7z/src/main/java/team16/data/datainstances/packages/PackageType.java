package team16.data.datainstances.packages;

public enum PackageType {
    NORMAL, EXPRESS, VALUE;
}
