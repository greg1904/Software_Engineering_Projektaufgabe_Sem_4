package team16.data.utils;

import team16.data.datainstances.packages.Package;

public interface ISearchAlgorithm {

    boolean checkPackage(Package packet);
}
