package team16.employees.types;

@SuppressWarnings("unused")
public enum AdminProfileType {
    A, B, C
}
