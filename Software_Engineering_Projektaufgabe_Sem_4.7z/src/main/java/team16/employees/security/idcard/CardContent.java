package team16.employees.security.idcard;

public enum CardContent {
    ID, NAME, ROLE, PIN, SUPERPIN
}
