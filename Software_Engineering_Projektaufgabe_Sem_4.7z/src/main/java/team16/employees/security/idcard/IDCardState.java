package team16.employees.security.idcard;

public enum IDCardState {//SOLID-Prinzip: State
    ACTIVE, LOCKED, INVALID
}
